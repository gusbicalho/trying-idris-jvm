#pragma once

void idris2_setupTerm();
int idris2_getTermCols();
int idris2_getTermLines();
