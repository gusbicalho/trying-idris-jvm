#pragma once

void* idris2_malloc(int size);
void idris2_free(void* ptr);
