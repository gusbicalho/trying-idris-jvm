#pragma once

int idris2_system(const char* command);
